package com.example.shazamytdl

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.shazamytdl.data.Track
import com.example.shazamytdl.data.TrackRepository
import com.example.shazamytdl.data.TrackStatus
import com.example.shazamytdl.download.YoutubeDlBridge
import com.example.shazamytdl.importer.ShazamCsvImporter
import com.example.shazamytdl.player.PlayerHolder
import com.example.shazamytdl.ui.theme.ShazamYtdlTheme
import com.example.shazamytdl.util.stableTrackId
import java.io.File


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val playerHolder = PlayerHolder(this)
        setContent {
            ShazamYtdlTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainScreen(playerHolder = playerHolder)
                }
            }
        }
    }
}

@Composable
private fun MainScreen(
    repository: TrackRepository = TrackRepository(LocalContext.current),
    importer: ShazamCsvImporter = ShazamCsvImporter(LocalContext.current),
    playerHolder: PlayerHolder? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val progressByTrack = remember { mutableStateMapOf<String, String>() }

    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var selectedForUrl by remember { mutableStateOf<Track?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun refreshTracks() {
        tracks = repository.list()
    }

    LaunchedEffect(Unit) {
        refreshTracks()
    }

    DisposableEffect(Unit) {
        onDispose { playerHolder?.release() }
    }

    message?.let { msg ->
        LaunchedEffect(msg) {
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            message = null
        }
    }

    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch(Dispatchers.IO) {
            runCatching {
                val imported = importer.import(uri)
                repository.upsertAll(imported)
                imported.size
            }.onSuccess { count ->
                withContext(Dispatchers.Main) {
                    refreshTracks()
                    message = "Uvoženih skladb: $count"
                }
            }.onFailure { error ->
                withContext(Dispatchers.Main) {
                    message = "CSV import napaka: ${error.message}"
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Shazam YTDL",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "MVP: Shazam CSV import, lokalna baza, youtubedl-android bridge za dovoljene URL-je in interni Media3 player.",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { csvLauncher.launch(arrayOf("text/*", "text/comma-separated-values", "application/csv", "application/vnd.ms-excel")) }) {
                Text("Import CSV")
            }
            OutlinedButton(onClick = { showAddDialog = true }) {
                Text("Dodaj ročno")
            }
        }

        Spacer(Modifier.height(12.dp))

        if (tracks.isEmpty()) {
            EmptyState()
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(tracks, key = { it.id }) { track ->
                    TrackCard(
                        track = track,
                        progressText = progressByTrack[track.id],
                        onSearch = {
                            val query = Uri.encode("${track.artist} ${track.title}")
                            context.startActivity(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse("https://www.youtube.com/results?search_query=$query")
                                )
                            )
                        },
                        onSetUrl = { selectedForUrl = track },
                        onDownload = {
                            val url = track.sourceUrl
                            if (url.isNullOrBlank()) {
                                selectedForUrl = track
                            } else {
                                scope.launch(Dispatchers.IO) {
                                    repository.updateStatus(track.id, TrackStatus.DOWNLOADING)
                                    withContext(Dispatchers.Main) {
                                        refreshTracks()
                                        progressByTrack[track.id] = "Priprava..."
                                    }
                                    runCatching {
                                        val outDir = File(context.filesDir, "music")
                                        val subPath = "${track.artist} - ${track.title}"
                                        YoutubeDlBridge.downloadAllowedUrl(context, url, outDir, subPath) { progress, eta ->
                                            scope.launch {
                                                progressByTrack[track.id] = "${progress.toInt()}% · ETA ${eta}s"
                                            }
                                        }
                                    }.onSuccess { file ->
                                        repository.updateDownloaded(track.id, file.absolutePath)
                                        withContext(Dispatchers.Main) {
                                            progressByTrack.remove(track.id)
                                            refreshTracks()
                                            message = "Preneseno: ${file.name}"
                                        }
                                    }.onFailure { error ->
                                        repository.updateStatus(track.id, TrackStatus.ERROR, error.message ?: error.toString())
                                        withContext(Dispatchers.Main) {
                                            progressByTrack.remove(track.id)
                                            refreshTracks()
                                            message = "Download napaka: ${error.message}"
                                        }
                                    }
                                }
                            }
                        },
                        onPlay = {
                            val path = track.localPath
                            if (path.isNullOrBlank()) {
                                message = "Najprej prenesi ali poveži lokalno datoteko."
                            } else {
                                runCatching { playerHolder?.playLocalFile(path) }
                                    .onFailure { message = "Player napaka: ${it.message}" }
                            }
                        }
                    )
                }
            }
        }
    }

    selectedForUrl?.let { track ->
        SetUrlDialog(
            track = track,
            onDismiss = { selectedForUrl = null },
            onSave = { url ->
                repository.updateSourceUrl(track.id, url)
                refreshTracks()
                selectedForUrl = null
            }
        )
    }

    if (showAddDialog) {
        AddTrackDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { artist, title, url ->
                val sourceUrl = url.takeIf { it.isNotBlank() }
                repository.upsert(
                    Track(
                        id = stableTrackId(title, artist),
                        title = title.trim(),
                        artist = artist.trim(),
                        sourceUrl = sourceUrl,
                        status = if (sourceUrl == null) TrackStatus.NEW else TrackStatus.URL_SET
                    )
                )
                refreshTracks()
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun EmptyState() {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Ni še skladb.", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Uvozi Shazam CSV ali dodaj testni URL ročno. CSV lahko vsebuje stolpce Title, Artist in opcijsko URL.")
        }
    }
}

@Composable
private fun TrackCard(
    track: Track,
    progressText: String?,
    onSearch: () -> Unit,
    onSetUrl: () -> Unit,
    onDownload: () -> Unit,
    onPlay: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(track.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(track.artist, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(6.dp))
            Text("Status: ${track.status.name}${progressText?.let { " · $it" } ?: ""}")
            track.sourceUrl?.let {
                Text(
                    text = "URL: $it",
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            track.localPath?.let {
                Text(
                    text = "File: $it",
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            track.lastError?.let {
                Text(
                    text = "Napaka: $it",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onSearch) { Text("YouTube search") }
                OutlinedButton(onClick = onSetUrl) { Text("URL") }
                Button(onClick = onDownload, enabled = track.status != TrackStatus.DOWNLOADING) { Text("Download") }
                OutlinedButton(onClick = onPlay, enabled = !track.localPath.isNullOrBlank()) { Text("Play") }
            }
        }
    }
}

@Composable
private fun SetUrlDialog(track: Track, onDismiss: () -> Unit, onSave: (String?) -> Unit) {
    var url by remember(track.id) { mutableStateOf(track.sourceUrl.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nastavi download URL") },
        text = {
            Column {
                Text("${track.artist} – ${track.title}")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("URL") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSave(url.takeIf { it.isNotBlank() }) }) { Text("Shrani") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Prekliči") }
        }
    )
}

@Composable
private fun AddTrackDialog(onDismiss: () -> Unit, onAdd: (artist: String, title: String, url: String) -> Unit) {
    var artist by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    val canSave = artist.isNotBlank() && title.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dodaj skladbo") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = artist,
                    onValueChange = { artist = it },
                    label = { Text("Artist") },
                    singleLine = true
                )
                OutlinedTextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title") },
                    singleLine = true
                )
                OutlinedTextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("URL, opcijsko") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(enabled = canSave, onClick = { onAdd(artist, title, url) }) { Text("Dodaj") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Prekliči") }
        }
    )
}
