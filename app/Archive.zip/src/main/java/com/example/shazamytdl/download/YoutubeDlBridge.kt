package com.example.shazamytdl.download

import android.content.Context
import android.util.Log
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.util.UUID

object YoutubeDlBridge {
    @Volatile
    private var initialized = false

    @Synchronized
    fun init(context: Context) {
        if (initialized) return
        val appContext = context.applicationContext
        YoutubeDL.getInstance().init(appContext)
        FFmpeg.getInstance().init(appContext)
        Aria2c.getInstance().init(appContext)
        initialized = true
    }

    fun downloadAllowedUrl(
        context: Context,
        url: String,
        outputDir: File,
        subPath: String? = null,
        onProgress: (progressPercent: Float, etaSeconds: Long) -> Unit
    ): File {
        init(context)
        require(url.startsWith("http://") || url.startsWith("https://")) {
            "URL must start with http:// or https://"
        }

        if (!outputDir.exists()) outputDir.mkdirs()
        val before = outputDir.listFiles()?.map { it.absolutePath }?.toSet().orEmpty()
        val fileNameTemplate = (subPath ?: "%(title).180s").replace("/", "_")
        val outputTemplate = File(outputDir, "$fileNameTemplate.%(ext)s").absolutePath

        val request = YoutubeDLRequest(url).apply {
            addOption("--no-playlist")
            addOption("--restrict-filenames")
            addOption("-x")
            addOption("--audio-format", "mp3")
            addOption("--audio-quality", "0")
            addOption("--add-metadata")
            addOption("-o", outputTemplate)
        }

        val processId = "download-${UUID.randomUUID()}"
        Log.d("YoutubeDlBridge", "Starting youtubedl-android process $processId")
        YoutubeDL.getInstance().execute(request, processId) { progress, etaInSeconds, _ ->
            onProgress(progress, etaInSeconds)
        }

        val candidates = outputDir.listFiles()?.filter { it.isFile }.orEmpty()
        return candidates
            .filter { it.absolutePath !in before || it.extension.equals("mp3", ignoreCase = true) }
            .maxByOrNull { it.lastModified() }
            ?: error("Download finished but output file was not found")
    }
}
