package com.example.shazamytdl.util

import java.security.MessageDigest

fun stableTrackId(title: String, artist: String): String {
    val key = "${artist.trim().lowercase()}::${title.trim().lowercase()}"
    val hash = MessageDigest.getInstance("SHA-256").digest(key.toByteArray())
    return hash.take(16).joinToString("") { "%02x".format(it) }
}
