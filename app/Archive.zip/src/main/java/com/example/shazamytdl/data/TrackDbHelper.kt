package com.example.shazamytdl.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class TrackDbHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE tracks (
                id TEXT PRIMARY KEY NOT NULL,
                title TEXT NOT NULL,
                artist TEXT NOT NULL,
                source_url TEXT,
                local_path TEXT,
                status TEXT NOT NULL,
                last_error TEXT,
                updated_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_tracks_artist_title ON tracks(artist, title)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS tracks")
        onCreate(db)
    }

    companion object {
        private const val DB_NAME = "tracks.db"
        private const val DB_VERSION = 1
    }
}

class TrackRepository(context: Context) {
    private val helper = TrackDbHelper(context.applicationContext)

    fun list(): List<Track> {
        val db = helper.readableDatabase
        val cursor = db.query(
            "tracks",
            null,
            null,
            null,
            null,
            null,
            "artist COLLATE NOCASE ASC, title COLLATE NOCASE ASC"
        )
        return cursor.use { c ->
            buildList {
                while (c.moveToNext()) add(c.toTrack())
            }
        }
    }

    fun upsert(track: Track) {
        val db = helper.writableDatabase
        val existing = getById(track.id)
        val merged = if (existing == null) {
            track
        } else {
            existing.copy(
                title = track.title,
                artist = track.artist,
                sourceUrl = track.sourceUrl ?: existing.sourceUrl,
                updatedAt = System.currentTimeMillis()
            )
        }
        db.insertWithOnConflict("tracks", null, merged.toValues(), SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun upsertAll(tracks: List<Track>) {
        tracks.forEach { upsert(it) }
    }

    fun getById(id: String): Track? {
        val db = helper.readableDatabase
        val cursor = db.query("tracks", null, "id=?", arrayOf(id), null, null, null)
        return cursor.use { if (it.moveToFirst()) it.toTrack() else null }
    }

    fun updateSourceUrl(id: String, url: String?) {
        val status = if (url.isNullOrBlank()) TrackStatus.NEW else TrackStatus.URL_SET
        updateFields(
            id,
            ContentValues().apply {
                put("source_url", url?.trim())
                put("status", status.name)
                putNull("last_error")
                put("updated_at", System.currentTimeMillis())
            }
        )
    }

    fun updateStatus(id: String, status: TrackStatus, error: String? = null) {
        updateFields(
            id,
            ContentValues().apply {
                put("status", status.name)
                if (error == null) putNull("last_error") else put("last_error", error)
                put("updated_at", System.currentTimeMillis())
            }
        )
    }

    fun updateDownloaded(id: String, localPath: String) {
        updateFields(
            id,
            ContentValues().apply {
                put("local_path", localPath)
                put("status", TrackStatus.DOWNLOADED.name)
                putNull("last_error")
                put("updated_at", System.currentTimeMillis())
            }
        )
    }

    private fun updateFields(id: String, values: ContentValues) {
        helper.writableDatabase.update("tracks", values, "id=?", arrayOf(id))
    }
}

private fun Track.toValues() = ContentValues().apply {
    put("id", id)
    put("title", title)
    put("artist", artist)
    put("source_url", sourceUrl)
    put("local_path", localPath)
    put("status", status.name)
    put("last_error", lastError)
    put("updated_at", updatedAt)
}

private fun Cursor.toTrack(): Track {
    fun str(name: String): String? {
        val idx = getColumnIndex(name)
        return if (idx >= 0 && !isNull(idx)) getString(idx) else null
    }
    fun nonNullStr(name: String): String = str(name).orEmpty()
    fun long(name: String): Long {
        val idx = getColumnIndex(name)
        return if (idx >= 0 && !isNull(idx)) getLong(idx) else 0L
    }

    return Track(
        id = nonNullStr("id"),
        title = nonNullStr("title"),
        artist = nonNullStr("artist"),
        sourceUrl = str("source_url"),
        localPath = str("local_path"),
        status = runCatching { TrackStatus.valueOf(nonNullStr("status")) }.getOrDefault(TrackStatus.NEW),
        lastError = str("last_error"),
        updatedAt = long("updated_at")
    )
}
