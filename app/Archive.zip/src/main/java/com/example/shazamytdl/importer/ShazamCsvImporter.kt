package com.example.shazamytdl.importer

import android.content.Context
import android.net.Uri
import com.example.shazamytdl.data.Track
import com.example.shazamytdl.data.TrackStatus
import com.example.shazamytdl.util.stableTrackId
import java.io.BufferedReader
import java.io.InputStreamReader

class ShazamCsvImporter(private val context: Context) {
    fun import(uri: Uri): List<Track> {
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: error("Cannot open selected CSV")

        BufferedReader(InputStreamReader(inputStream)).use { reader ->
            val rows = reader.lineSequence()
                .filter { it.isNotBlank() }
                .map { parseCsvLine(it) }
                .toList()

            if (rows.isEmpty()) return emptyList()

            val header = rows.first().map { it.trim().lowercase() }
            val dataRows = rows.drop(1)

            val titleIndex = header.indexByAny("title", "track title", "track", "song", "name")
            val artistIndex = header.indexByAny("artist", "subtitle", "performer", "author")
            val urlIndex = header.indexByAny("url", "link", "shazam url", "track url", "source url", "youtube url")

            val fallbackTitleIndex = if (titleIndex >= 0) titleIndex else 0
            val fallbackArtistIndex = if (artistIndex >= 0) artistIndex else 1

            return dataRows.mapNotNull { row ->
                val title = row.getOrNull(fallbackTitleIndex)?.trim().orEmpty()
                val artist = row.getOrNull(fallbackArtistIndex)?.trim().orEmpty()
                val url = row.getOrNull(urlIndex)?.trim()?.takeIf { it.startsWith("http") }

                if (title.isBlank() || artist.isBlank()) return@mapNotNull null

                Track(
                    id = stableTrackId(title, artist),
                    title = title,
                    artist = artist,
                    sourceUrl = url,
                    status = if (url == null) TrackStatus.NEW else TrackStatus.URL_SET
                )
            }
        }
    }

    private fun List<String>.indexByAny(vararg names: String): Int {
        names.forEach { wanted ->
            val exact = indexOf(wanted)
            if (exact >= 0) return exact
        }
        names.forEach { wanted ->
            val fuzzy = indexOfFirst { it.contains(wanted) }
            if (fuzzy >= 0) return fuzzy
        }
        return -1
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        var i = 0

        while (i < line.length) {
            val ch = line[i]
            when {
                ch == '"' && inQuotes && i + 1 < line.length && line[i + 1] == '"' -> {
                    current.append('"')
                    i++
                }
                ch == '"' -> inQuotes = !inQuotes
                ch == ',' && !inQuotes -> {
                    result.add(current.toString())
                    current.clear()
                }
                else -> current.append(ch)
            }
            i++
        }
        result.add(current.toString())
        return result
    }
}
