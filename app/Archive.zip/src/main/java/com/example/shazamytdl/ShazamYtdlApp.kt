package com.example.shazamytdl

import android.app.Application
import android.util.Log
import com.example.shazamytdl.download.YoutubeDlBridge

class ShazamYtdlApp : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            YoutubeDlBridge.init(this)
        } catch (t: Throwable) {
            Log.e("ShazamYtdlApp", "youtubedl-android init failed; download can retry later", t)
        }
    }
}
