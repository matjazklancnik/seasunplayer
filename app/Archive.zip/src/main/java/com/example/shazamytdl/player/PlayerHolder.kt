package com.example.shazamytdl.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import java.io.File

class PlayerHolder(context: Context) {
    private val player = ExoPlayer.Builder(context).build()

    fun playLocalFile(path: String) {
        val file = File(path)
        require(file.exists()) { "File does not exist: $path" }
        player.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
        player.prepare()
        player.play()
    }

    fun stop() {
        player.stop()
    }

    fun release() {
        player.release()
    }
}
